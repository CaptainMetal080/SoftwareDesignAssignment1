import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Banana implements Fruit{
    @Override
    public void getPrice() {
        int rows = 2;
        int columns = 3;

        String[][] apple = new String[rows][columns];
        String[][] banana = new String[rows][columns];

        try {
            int i = -1, j = 0, x=-1, y=0;

            File myObj = new File("Fruits.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                String fruit = myReader.nextLine();
                String cost = myReader.nextLine();

                if (fruit.contains("Apple")){
                    i++;
                    apple[i][j] = fruit;
                    j++;

                    apple[i][j] = cost;
                }

                else if (fruit.contains("Banana")){
                    x++;
                    banana[x][y] = fruit;
                    y++;

                    banana[x][y] = cost;
                }
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        System.out.println(banana[0][0] + " " + banana[0][1]);
        System.out.println(banana[1][1] + " " + banana[1][2]);
    }
}
