public interface Fruit {

    void getPrice();


}
