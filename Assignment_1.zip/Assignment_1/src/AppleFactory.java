public class AppleFactory extends GroceryProductFactory{

}
